-- helper file for require() tests
module( 'sample', package.seeall )
function h()
	print 'in sample.h' 
end
print 'loading sample.lua'

