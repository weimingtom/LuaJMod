package org.luaj.vm2.lib.jse;

public interface TestInterface { 
	String interface_method(String x);
}